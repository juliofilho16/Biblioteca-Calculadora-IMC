using NUnit.Framework;
using CalculadoraIMC.Models;
using CalculadoraIMC.Services;

namespace TestCalculadoraIMC
{
  public class TestsCalculoIMC
  {

    [TestCase(0, 1.4)]
    [TestCase(-50, 1.57)]
    [TestCase(54, -1.78)]
    [TestCase(54, 1.64)]
    public void CalculoIMC(double peso, double altura)
    {
      RetornoIMCModel retorno = CalculadoraIMCServices.CalculoIMC(peso: peso, altura: altura);
      if (retorno.Erro)
        Assert.Fail(retorno.Mensagem);
      else
        Assert.Pass($"IMC: {retorno.IMC} Classifica��o: {retorno.Classificacao.Titulo} - {retorno.Classificacao.Mensagem}");
    }

    [SetUp]
    public void Setup()
    {
    }

  }
}