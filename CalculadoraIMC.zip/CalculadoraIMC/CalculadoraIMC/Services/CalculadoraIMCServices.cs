﻿using CalculadoraIMC.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CalculadoraIMC.Services
{
  public static class CalculadoraIMCServices
  {
    public static RetornoIMCModel CalculoIMC(double peso, double altura)
    {
      IMCModel imcModel = new IMCModel(peso: peso, altura: altura);
      return new RetornoIMCModel(IMC: imcModel.IMC);
    }
  }
}
