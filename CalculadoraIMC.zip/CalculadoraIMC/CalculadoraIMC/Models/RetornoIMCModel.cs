﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CalculadoraIMC.Models
{
  public class RetornoIMCModel
  {
    public RetornoIMCModel(double IMC)
    {
      imc = IMC;
    }
    private readonly double imc;
    public string IMC { get { return String.Format("{0:0.00}", this.imc); } }
    public bool Erro { get { return imc < 0; } }
    public string Mensagem { get { return this.Erro ? "Erro ao realizar o cálculo." : "cálculo realizado com sucesso"; } }
    public ClassificacaoIMCModel Classificacao
    {
      get
      {
        if (this.imc <=16.99)
          return new ClassificacaoIMCModel(titulo: "Baixo peso muito grave", mensagem: "Queda de cabelo, infertilidade, ausência menstrual");
        else if (this.imc <= 18.4)
          return new ClassificacaoIMCModel(titulo: "Baixo peso", mensagem: "Fadiga, stress, ansiedade");
        else if (this.imc <= 24.9)
          return new ClassificacaoIMCModel(titulo: "Peso normal", mensagem: "Menor risco de doenças cardíacas e vasculares");
        else if (this.imc <= 29.99)
          return new ClassificacaoIMCModel(titulo: "Acima do peso", mensagem: "Fadiga, má circulação, varizes");
        else if (this.imc <= 34.99)
          return new ClassificacaoIMCModel(titulo: "Obesidade Grau I", mensagem: "Diabetes, angina, infarto, aterosclerose");
        else if (this.imc <= 40)
          return new ClassificacaoIMCModel(titulo: "Obesidade Grau II", mensagem: "Apneia do sono, falta de ar");
        else
          return new ClassificacaoIMCModel(titulo: "Obesidade Grau III", mensagem: "Refluxo, dificuldade para se mover, escaras, diabetes, infarto, AVC");
      }
    }

  }
}
