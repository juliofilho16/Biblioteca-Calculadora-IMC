﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CalculadoraIMC.Models
{
  public class ClassificacaoIMCModel
  {
    public ClassificacaoIMCModel(string titulo, string mensagem)
    {
      Titulo = titulo;
      Mensagem = mensagem;
    }

    public string Titulo { get; set; }
    public string Mensagem { get; set; }
  }
}
