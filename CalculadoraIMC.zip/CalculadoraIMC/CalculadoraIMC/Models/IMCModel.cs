﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CalculadoraIMC.Models
{
  public class IMCModel
  {
    public IMCModel(double peso, double altura)
    {
      this.peso = peso;
      this.altura = altura;
    }
    private double erro = -1;
    private double peso { get; set; }
    private double altura { get; set; }
    public double IMC
    {
      get
      {
        if (peso < 1)
          return this.erro;

        if (altura < 1)
          return this.erro;

        double r = (peso / (altura * altura));
        return Math.Round(r, 2);
      }
    }
  }
}
